<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма регистрации пользователя</title>
</head>
<body>
<style>
        form {
            text-align: center;
            background-color: #f2f2f2;
            padding: 20px;
            width: 300px;
            margin: 0 auto;
            border-radius: 10px;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0 20px 0;
            box-sizing: border-box; /* учитываем padding в размере элемента */
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
    <p>Регистрация пользователя:</p>
    <form action="/labs/lab8/form.php" method="post">
    <label>ФИО:</label>
        <input type="text" id="inputname" name="input-name"  placeholder="Введите свое ФИО">    
    <label>Логин:</label>
        <input type="text" id="login" name="login" placeholder="Введите свой логин">
    <label>Пароль:</label>
        <input type="password" id="password" name="password" placeholder="Введите свой пароль">
    <label>Дата рождения:</label>
        <input type="date" id="date" name="date" placeholder="Введите свою дату рождения">
        <input type="submit" name="submit-form" value="Зарегистрироваться"> 
    </form>
    <?php
    if(isset($_POST["submit-form"]))
{
    if (!empty($_POST['input-name']) && !empty($_POST['login']) && !empty($_POST['password']) && !empty($_POST['date'])){
        $inputname = $_POST['input-name'];
        $login = $_POST['login'];
        $password = $_POST['password'];
        $date = $_POST['date'];
    }
}
?>
</body>
</html>
