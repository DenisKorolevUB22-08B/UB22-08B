<?php
session_start();
if (isset($_SESSION["user_id"])) {
    header("Location: main.php");
    exit();
}
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portfolio";

$db = new mysqli($servername, $username, $password, $dbname);


if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];


    $stmt = $db->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();


        if (password_verify($password, $user["password"])) {



            $_SESSION["user_id"] = $user["id"];
            $_SESSION["username"] = $user["username"];

            echo "success";
            header("Location: main.php");
            exit();
        } else {
            echo "Неверное имя пользователя или пароль";
        }
    } else {
        echo "Неверное имя пользователя или пароль";
    }

    $stmt->close();
}

$db->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="login.css">
    <title>Авторизация</title>

</head>
<body>
    <h2>Авторизация</h2>
    <form method="post">
        <div>
            <label for="username">Имя пользователя:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Войти</button>
    </form>

</body>
</html>
