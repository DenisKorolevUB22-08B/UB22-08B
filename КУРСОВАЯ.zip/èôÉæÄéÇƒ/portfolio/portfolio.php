<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portfolio";

$db = new mysqli($servername, $username, $password, $dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION["user_id"];
    $description = htmlspecialchars($_POST["description"]);

    $uploadDir = "uploads/";
    $uploadedFile = $uploadDir . basename($_FILES["image"]["name"]);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $uploadedFile)) {

        $stmt = $db->prepare("INSERT INTO achievements (user_id, image_path, description) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $user_id, $uploadedFile, $description);

        if ($stmt->execute()) {
            header("Location: {$_SERVER['REQUEST_URI']}");
            exit();
        } else {
            echo "Ошибка при добавлении достижения: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Ошибка при загрузке изображения.";
    }
}

$user_id = $_SESSION["user_id"];
$result = $db->query("SELECT * FROM achievements WHERE user_id = $user_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои достижения</title>
    <style>
        input[type="file"] {
            display: block;
            margin-bottom: 10px;
        }

        #image-preview {
            max-width: 300px;
            max-height: 300px;
            margin-bottom: 20px;
        }

        .achievements-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .achievement-card {
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            max-height: 600px;
        }

        .achievement-image {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .achievement-description {
            padding: 10px;
            margin: 0;
        }

        .achievement {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
    </style>

    <link rel="stylesheet" href="portfolio.css">
</head>
<body>
<h1>Мои достижения</h1>
<form id="achievement-form" enctype="multipart/form-data" method="post">
    <label for="image-upload" class="upload-label">Выберите фотографию:</label>
    <input type="file" id="image-upload" name="image" accept="image/*">
    <div>
        <label for="achievement-description">Описание:</label>
        <textarea id="achievement-description" name="description" rows="4"></textarea>
    </div>
    <button type="submit">Загрузить</button>
</form>

<div class="achievements-container">
    <?php while ($row = $result->fetch_assoc()) { ?>
        <div class="achievement-card">
            <div class="achievement">
                <img class="achievement-image" src="<?php echo $row['image_path']; ?>" alt="Достижение">
                <p class="achievement-description"><?php echo $row['description']; ?></p>
            </div>
        </div>
    <?php } ?>
</div>
</body>
</html>

<?php
$db->close();
?>
