<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "portfolio";

$db = new mysqli($servername, $username, $password, $dbname);
session_start();
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
if (isset($_SESSION["user_id"])) {
    header("Location: main.php");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm-password"];

    // Проверка совпадения паролей
    if ($password != $confirmPassword) {
        echo "Пароли не совпадают";
        exit();
    }
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $hashedPassword);

    $checkStmt = $db->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $checkStmt->bind_param("ss", $username, $email);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        echo "Имя пользователя или почта уже заняты";
        exit();
    }

    if ($stmt->execute()) {
        $userId = $stmt->insert_id;
        $roleStmt = $db->prepare("INSERT INTO permissions (user_id, role_id) VALUES (?, (SELECT id FROM roles WHERE name = 'user'))");
        $roleStmt->bind_param("i", $userId);
        $roleStmt->execute();

        echo "Регистрация успешна!";
        header("Location: login.php");
        exit();
    } else {
        echo "Ошибка при регистрации: " . $stmt->error;
    }

    $stmt->close();
    $checkStmt->close();
}

$db->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="registration.css">
</head>
<body>
<h1>Регистрация</h1>
<form method="post">
    <div class="form-group">
        <label for="username">Имя пользователя:</label>
        <input type="text" id="username" name="username" required>
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
    </div>
    <div class="form-group">
        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>
    </div>
    <div class="form-group">
        <label for="confirm-password">Повторите пароль:</label>
        <input type="password" id="confirm-password" name="confirm-password" required>
    </div>
    <button type="submit">Зарегистрироваться</button>
</form>
</body>
</html>

