<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="styles.css">
    <style>
        #my-portfolio {
            padding: 10px 20px;
            background-color: #0000FF; /* Синий цвет */
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 18px;
        }
        #logout {
            padding: 10px 20px;
            background-color: #FF0000;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-size: 18px;
            margin-left: 10px;
        }
        #user-greeting{
            color: white;
        }

    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Моё портфолио</title>
    <script>
        function goToLoginPage() {
            window.location.href = "login.php";
        }

        function goToRegistrationPage() {
            window.location.href = "registration.php";
        }

        function goToPortfolioPage() {
            window.location.href = "portfolio.php";
        }

        function logout() {
            window.location.href = "logout.php";
        }
    </script>
</head>
<body>
<header>
    <div class="logo">
        <img src="logo.png" alt="Логотип Моего портфолио">
    </div>

    <?php
    session_start();
    if (isset($_SESSION['username'])) {
        echo '<div id="user-greeting">Привет, ' . $_SESSION['username'] . '!</div>';
        echo '<button id="logout" onclick="logout()">Выйти</button>';
    } else {
        echo '<button id="register" onclick="goToRegistrationPage()">Регистрация</button>';
        echo '<button id="login" onclick="goToLoginPage()">Войти</button>';
    }
    ?>
</header>
<div> Здесь  вы можете демонстрировать свои профессиональные достижения, работы и навыки. Это удобный способ представить свои проекты, искусство, документацию или другие работы широкой аудитории в интерактивной и привлекательной форме.</div>
    <style>
        /* Стиль для изображений */
        .photo {
            display: flex;
            justify-content: space-around;
            align-items: center;
            background-color: #333;
            padding: 20px;
        }
        img {
            width: 30%;
            border: 5px solid #222;
            border-radius: 10px;
        }
    </style>

    <div class="photo">
        <img src="пример1.png" alt="Пример 1">
        <img src="пример2.png" alt="Пример 2">
        <img src="пример3.png" alt="Пример 3">
    </div>



 <div>Ниже, нажав на кнопку "Моё портфолио", вы сможете загружать и отслеживать свои достижения. Дерзайте!</div>

<main class="portfolio-section">
    <?php
    if (isset($_SESSION['username'])) {

    echo '<button id="my-portfolio" onclick="goToPortfolioPage()">Моё портфолио</button>';
    }
    ?>
</main>
</body>
</html>
